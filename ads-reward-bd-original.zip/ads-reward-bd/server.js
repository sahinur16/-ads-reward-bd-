require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const production = process.env.NODE_ENV === 'production';
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error('SESSION_SECRET must be set to a random string of at least 32 characters. Copy .env.example to .env and configure it.');
  process.exit(1);
}
const dbFile = path.resolve(process.env.DB_FILE || './data/ads-reward-bd.sqlite');
fs.mkdirSync(path.dirname(dbFile), { recursive: true });
const db = new Database(dbFile);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
 points INTEGER NOT NULL DEFAULT 0 CHECK(points >= 0),
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS ledger (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id),
 points_delta INTEGER NOT NULL,
 event_type TEXT NOT NULL,
 note TEXT NOT NULL,
 reference TEXT UNIQUE,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS withdrawals (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id),
 method TEXT NOT NULL CHECK(method IN ('bKash','Nagad')),
 account_number TEXT NOT NULL,
 points INTEGER NOT NULL CHECK(points >= 1000),
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','paid')),
 admin_note TEXT,
 payment_reference TEXT,
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS premium_requests (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id),
 plan TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"],
  imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], objectSrc: ["'none'"], upgradeInsecureRequests: production ? [] : null
} }}));
app.use(express.json({ limit: '20kb' }));
app.use(express.urlencoded({ extended: false, limit: '20kb' }));
if (production) app.set('trust proxy', 1);
app.use(session({
 store: new SQLiteStore({ db: 'sessions.sqlite', dir: path.dirname(dbFile), concurrentDB: true }),
 name: 'adsreward.sid', secret: process.env.SESSION_SECRET,
 resave: false, saveUninitialized: false,
 cookie: { httpOnly: true, secure: production, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 8 }
}));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/auth/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: 'draft-7', legacyHeaders: false }));

const getUser = id => db.prepare('SELECT id,name,email,role,points,created_at FROM users WHERE id=?').get(id);
function requireAuth(req,res,next){ if(!req.session.userId) return res.status(401).json({error:'প্রথমে লগইন করুন।'}); next(); }
function requireAdmin(req,res,next){ const user=req.session.userId && getUser(req.session.userId); if(!user || user.role!=='admin') return res.status(403).json({error:'এই কাজের জন্য অ্যাডমিন অনুমতি প্রয়োজন।'}); next(); }
function csrf(req,res,next){
  const safe = ['GET','HEAD','OPTIONS'].includes(req.method);
  if(safe) return next();
  const origin = req.get('origin');
  if(origin && process.env.APP_ORIGIN && origin !== process.env.APP_ORIGIN) return res.status(403).json({error:'Origin যাচাই ব্যর্থ।'});
  const supplied = req.get('x-csrf-token') || req.body?._csrf;
  if(!req.session.csrfToken || supplied !== req.session.csrfToken) return res.status(403).json({error:'সেশন যাচাই ব্যর্থ। পেজ রিফ্রেশ করে আবার চেষ্টা করুন।'});
  next();
}
app.use('/api', csrf);
app.get('/api/csrf', (req,res)=>{ if(!req.session.csrfToken) req.session.csrfToken=crypto.randomBytes(24).toString('hex'); res.json({token:req.session.csrfToken}); });

app.post('/api/auth/register', async (req,res)=>{
 const name=String(req.body.name||'').trim().slice(0,70);
 const email=String(req.body.email||'').trim().toLowerCase();
 const password=String(req.body.password||'');
 if(name.length<2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length<10) return res.status(400).json({error:'নাম, সঠিক ইমেইল ও অন্তত ১০ অক্ষরের পাসওয়ার্ড দিন।'});
 try {
  const hash=await bcrypt.hash(password,12);
  const result=db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name,email,hash);
  req.session.userId=Number(result.lastInsertRowid);
  res.json({user:getUser(req.session.userId)});
 } catch(e){ if(String(e.code)==='SQLITE_CONSTRAINT_UNIQUE') return res.status(409).json({error:'এই ইমেইলে অ্যাকাউন্ট আছে।'}); console.error(e); res.status(500).json({error:'অ্যাকাউন্ট তৈরি করা যায়নি।'}); }
});
app.post('/api/auth/login', async (req,res)=>{
 const email=String(req.body.email||'').trim().toLowerCase(); const password=String(req.body.password||'');
 const user=db.prepare('SELECT * FROM users WHERE email=?').get(email);
 if(!user || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({error:'ইমেইল বা পাসওয়ার্ড সঠিক নয়।'});
 req.session.regenerate(err=>{ if(err) return res.status(500).json({error:'লগইন ব্যর্থ।'}); req.session.userId=user.id; req.session.csrfToken=crypto.randomBytes(24).toString('hex'); res.json({user:getUser(user.id),csrfToken:req.session.csrfToken}); });
});
app.post('/api/auth/logout', requireAuth, (req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me', requireAuth, (req,res)=>res.json({user:getUser(req.session.userId),csrfToken:req.session.csrfToken}));
app.get('/api/ledger', requireAuth, (req,res)=>res.json({items:db.prepare('SELECT points_delta,event_type,note,created_at FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT 50').all(req.session.userId)}));

app.post('/api/withdrawals', requireAuth, (req,res)=>{
 const method=String(req.body.method||''); const number=String(req.body.accountNumber||'').trim(); const points=Number(req.body.points);
 if(!['bKash','Nagad'].includes(method) || !/^01[3-9]\d{8}$/.test(number) || !Number.isSafeInteger(points) || points<1000) return res.status(400).json({error:'bKash/Nagad নম্বর ও কমপক্ষে ১,০০০ পয়েন্ট দিন।'});
 const submit=db.transaction(()=>{
  const user=db.prepare('SELECT points FROM users WHERE id=?').get(req.session.userId);
  if(!user || user.points<points) throw new Error('NOT_ENOUGH_POINTS');
  db.prepare('UPDATE users SET points=points-? WHERE id=?').run(points,req.session.userId);
  const info=db.prepare('INSERT INTO withdrawals(user_id,method,account_number,points) VALUES(?,?,?,?)').run(req.session.userId,method,number,points);
  db.prepare('INSERT INTO ledger(user_id,points_delta,event_type,note,reference) VALUES(?,?,?,?,?)').run(req.session.userId,-points,'redeem_hold','রিডিম আবেদন; অ্যাডমিন যাচাইয়ের অপেক্ষায়','withdrawal-'+info.lastInsertRowid);
  return Number(info.lastInsertRowid);
 });
 try { const id=submit(); res.json({ok:true,id,message:'আবেদন জমা হয়েছে। অ্যাডমিন যাচাই করবেন; এটি পেমেন্টের নিশ্চয়তা নয়।'}); }
 catch(e){ if(e.message==='NOT_ENOUGH_POINTS') return res.status(400).json({error:'আপনার পয়েন্ট পর্যাপ্ত নয়।'}); console.error(e); res.status(500).json({error:'আবেদন জমা হয়নি।'}); }
});
app.get('/api/withdrawals/mine', requireAuth, (req,res)=>res.json({items:db.prepare('SELECT id,method,points,status,admin_note,created_at,reviewed_at FROM withdrawals WHERE user_id=? ORDER BY id DESC LIMIT 30').all(req.session.userId)}));
app.post('/api/premium/request', requireAuth, (req,res)=>{
 const plan=String(req.body.plan||'').trim(); if(!['basic','plus','pro'].includes(plan)) return res.status(400).json({error:'সঠিক প্ল্যান বেছে নিন।'});
 const info=db.prepare('INSERT INTO premium_requests(user_id,plan) VALUES(?,?)').run(req.session.userId,plan);
 res.json({ok:true,id:Number(info.lastInsertRowid),message:'প্রিমিয়াম অনুরোধ জমা হয়েছে। এটি এখনো পেমেন্ট বা সাবস্ক্রিপশন নয়।'});
});

// Admin routes: every decision is recorded in the database; payout remains manual.
app.get('/api/admin/overview', requireAuth, requireAdmin, (req,res)=>{
 res.json({users:db.prepare('SELECT COUNT(*) n FROM users').get().n, pending:db.prepare("SELECT COUNT(*) n FROM withdrawals WHERE status='pending'").get().n, withdrawals:db.prepare(`SELECT w.id,w.user_id,u.name,u.email,w.method,w.account_number,w.points,w.status,w.created_at FROM withdrawals w JOIN users u ON u.id=w.user_id ORDER BY w.id DESC LIMIT 100`).all()});
});
app.post('/api/admin/withdrawals/:id/review', requireAuth, requireAdmin, (req,res)=>{
 const id=Number(req.params.id); const decision=String(req.body.decision||''); const note=String(req.body.note||'').trim().slice(0,300);
 if(!Number.isSafeInteger(id) || !['approve','reject','paid'].includes(decision)) return res.status(400).json({error:'সঠিক সিদ্ধান্ত দিন।'});
 const tx=db.transaction(()=>{
  const w=db.prepare('SELECT * FROM withdrawals WHERE id=?').get(id); if(!w) throw new Error('NOT_FOUND');
  if(decision==='approve') { if(w.status!=='pending') throw new Error('BAD_STATE'); db.prepare("UPDATE withdrawals SET status='approved',admin_note=?,reviewed_at=datetime('now') WHERE id=?").run(note,id); }
  if(decision==='paid') { if(w.status!=='approved') throw new Error('BAD_STATE'); db.prepare("UPDATE withdrawals SET status='paid',admin_note=?,reviewed_at=datetime('now') WHERE id=?").run(note,id); }
  if(decision==='reject') { if(!['pending','approved'].includes(w.status)) throw new Error('BAD_STATE'); db.prepare("UPDATE users SET points=points+? WHERE id=?").run(w.points,w.user_id); db.prepare("INSERT INTO ledger(user_id,points_delta,event_type,note,reference) VALUES(?,?,?,?,?)").run(w.user_id,w.points,'redeem_refund','রিডিম আবেদন বাতিল; পয়েন্ট ফেরত','withdrawal-refund-'+id); db.prepare("UPDATE withdrawals SET status='rejected',admin_note=?,reviewed_at=datetime('now') WHERE id=?").run(note,id); }
 });
 try { tx(); res.json({ok:true,message:'অ্যাডমিন সিদ্ধান্ত সংরক্ষিত হয়েছে।'}); } catch(e){ if(e.message==='NOT_FOUND') return res.status(404).json({error:'আবেদন পাওয়া যায়নি।'}); if(e.message==='BAD_STATE') return res.status(409).json({error:'এই আবেদনের বর্তমান অবস্থায় এই সিদ্ধান্ত দেওয়া যাবে না।'}); console.error(e); res.status(500).json({error:'সিদ্ধান্ত সংরক্ষণ ব্যর্থ।'}); }
});
app.get('/api/admin/users', requireAuth, requireAdmin, (req,res)=>res.json({items:db.prepare('SELECT id,name,email,role,points,created_at FROM users ORDER BY id DESC LIMIT 200').all()}));
app.post('/api/admin/users/:id/points', requireAuth, requireAdmin, (req,res)=>{
 const userId=Number(req.params.id), delta=Number(req.body.delta), note=String(req.body.note||'').trim().slice(0,200);
 if(!Number.isSafeInteger(userId)||!Number.isSafeInteger(delta)||delta===0||Math.abs(delta)>100000||note.length<3) return res.status(400).json({error:'সঠিক পয়েন্ট পরিবর্তন ও কারণ লিখুন।'});
 const tx=db.transaction(()=>{const u=db.prepare('SELECT points FROM users WHERE id=?').get(userId); if(!u) throw new Error('NOT_FOUND'); if(u.points+delta<0) throw new Error('NEGATIVE'); db.prepare('UPDATE users SET points=points+? WHERE id=?').run(delta,userId); db.prepare('INSERT INTO ledger(user_id,points_delta,event_type,note,reference) VALUES(?,?,?,?,?)').run(userId,delta,'admin_adjustment',note,'admin-'+crypto.randomUUID());});
 try{tx();res.json({ok:true});}catch(e){if(e.message==='NOT_FOUND')return res.status(404).json({error:'ইউজার নেই।'});if(e.message==='NEGATIVE')return res.status(400).json({error:'ব্যালেন্স শূন্যের নিচে যেতে পারবে না।'});res.status(500).json({error:'পরিবর্তন ব্যর্থ।'});}
});

// No fake ad rewards. This endpoint is intentionally absent until a provider's
// approved server-to-server verification flow and fraud controls are configured.
app.get('/api/integrations/status', (req,res)=>res.json({bkashConfigured:Boolean(process.env.BKASH_BASE_URL&&process.env.BKASH_APP_KEY&&process.env.BKASH_APP_SECRET&&process.env.BKASH_USERNAME&&process.env.BKASH_PASSWORD),nagadConfigured:Boolean(process.env.NAGAD_BASE_URL&&process.env.NAGAD_MERCHANT_ID&&process.env.NAGAD_MERCHANT_PRIVATE_KEY),rewardedAdsEnabled:false,note:'Payment APIs and rewarded ads are not active. Add official provider-approved server-side integrations before accepting real payments or granting ad rewards.'}));

app.use(express.static(path.join(__dirname,'public')));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));

async function bootstrapAdmin(){
 const email=String(process.env.ADMIN_EMAIL||'').trim().toLowerCase(); const password=String(process.env.ADMIN_PASSWORD||'');
 if(!email || !password){console.warn('ADMIN_EMAIL/ADMIN_PASSWORD not set. No initial admin created.');return;}
 if(password.length<14){console.warn('ADMIN_PASSWORD should be at least 14 characters. Initial admin not created.');return;}
 const existing=db.prepare('SELECT id,role FROM users WHERE email=?').get(email);
 if(existing){if(existing.role!=='admin') db.prepare("UPDATE users SET role='admin' WHERE id=?").run(existing.id);return;}
 const hash=await bcrypt.hash(password,12);
 db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')").run('Administrator',email,hash);
 console.log('Initial admin created from environment variables.');
}
bootstrapAdmin().then(()=>app.listen(PORT,()=>console.log(`ads reward BD listening on port ${PORT}`))).catch(err=>{console.error(err);process.exit(1)});
