# ads reward BD — আসল সার্ভার-ভিত্তিক Starter

এই প্রকল্পে রয়েছে:
- Express server + SQLite database
- bcrypt password hashing, session cookie, login/register/logout
- সার্ভার-সাইড points balance ও immutable-style ledger entries
- bKash/Nagad নম্বরসহ manual withdrawal request
- Admin-only review: approve / reject (পয়েন্ট ফেরত) / paid mark
- Admin user list এবং audit ledger-এর মাধ্যমে points adjustment
- Premium request scaffold
- Header, dashboard, content, rewarded এবং footer ad placement placeholders
- bKash/Nagad official integration readiness status endpoint

## চালানোর নিয়ম (Android/PC)

সার্ভার চালানোর জন্য Node.js 20+ পরিবেশ দরকার। শুধু ফোনে HTML ফাইল খুললে backend চলবে না। Android-এ Termux বা কোনো Node hosting, অথবা VPS/Render/Railway-এর মতো hosting environment ব্যবহার করতে পারেন; hosting provider-এর বর্তমান Node/SQLite support যাচাই করুন।

1. Node.js 20+ ইনস্টল করুন।
2. এই project folder-এ terminal খুলুন।
3. `.env.example` কপি করে `.env` তৈরি করুন।
4. `.env`-এ অন্তত 32-character random `SESSION_SECRET`, `APP_ORIGIN`, `ADMIN_EMAIL`, এবং 14+ character unique `ADMIN_PASSWORD` দিন। Production-এ `APP_ORIGIN` হবে HTTPS domain, যেমন `https://your-domain.example`।
5. চালান: `npm install`
6. তারপর: `npm start`
7. Browser-এ `http://localhost:3000` খুলুন। Hosting-এ হলে আপনার HTTPS domain ব্যবহার করুন।

প্রথম startup-এ `.env`-এর admin email/password দিয়ে admin account তৈরি হবে। Admin password কখনো source code-এ লিখবেন না। প্রথম deployment-এর পর strong secret রাখুন এবং `.env`/database public repo-তে দেবেন না।

## গুরুত্বপূর্ণ সীমা ও production checklist

- এটি production-ready audited financial platform নয়। Public launch-এর আগে security review, backups, monitoring, privacy/terms/refund policy, age eligibility, abuse/fraud protection, email verification, password reset, CSRF/origin review, and operational support যোগ করুন।
- Session store SQLite হলেও shared hosting/multi-instance deployments-এ managed persistent storage ও suitable session store ব্যবহার করুন। Database file persistent volume-এ রাখুন।
- Point-to-cash conversion rate ও minimum eligibility স্পষ্টভাবে প্রকাশ করুন। Points-এর value বাস্তবে অর্থায়িত না হলে নগদ রিডিমের প্রতিশ্রুতি দেবেন না।
- Admin `Paid` বোতাম শুধু status পরিবর্তন করে; এটি bKash/Nagad-এ টাকা পাঠায় না। বাস্তব payout-এর আগে official merchant agreement, credentials, signed callback verification, idempotency, transaction reconciliation এবং provider-এর নির্দেশনা বাস্তবায়ন করতে হবে। Credentials client-side-এ কখনো দেবেন না।
- Rewarded ad endpoint ইচ্ছাকৃতভাবে নেই। Network-এর written approval এবং documented server-side verification ছাড়া বিজ্ঞাপন দেখার বিনিময়ে points grant করবেন না। নিজের বিজ্ঞাপনে ক্লিক, incentivized ad click, impression manipulation বা bot traffic নিষিদ্ধ/ঝুঁকিপূর্ণ হতে পারে।
- AdSense/Adsterra/Mediavine/Ezoic/PropellerAds-এর code একে অন্যের জায়গায় বসে না। প্রতিটি নেটওয়ার্কের নিজস্ব approval, format, consent/privacy এবং traffic policy অনুসরণ করুন।
- `APP_ORIGIN`-এর মান incoming Origin-এর সঙ্গে মেলাতে হবে। Reverse proxy/hosting অনুযায়ী secure cookie ও HTTPS ঠিকভাবে configure করুন।
- Production-এ dependency audit করুন: `npm audit`; patch/version review করুন।

## API সংক্ষিপ্ত তালিকা

- `GET /api/csrf`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/me`
- `GET /api/ledger`
- `POST /api/withdrawals`
- `GET /api/withdrawals/mine`
- `POST /api/premium/request`
- Admin: `GET /api/admin/overview`, `GET /api/admin/users`, `POST /api/admin/withdrawals/:id/review`, `POST /api/admin/users/:id/points`
- `GET /api/integrations/status`

সব POST API-তে session CSRF token header `x-csrf-token` প্রয়োজন; frontend স্বয়ংক্রিয়ভাবে পাঠায়।
